<<<<<<< HEAD
const CACHE_NAME = 'dashboard-matriculas-cache-v15';
=======
const CACHE_NAME = 'dashboard-matriculas-cache-v8.0';
>>>>>>> 51b834b (update tela de login customizada)
const urlsToCache = [
  '/',
  '/index.html',
  // Adicione outros assets estáticos que não sejam das APIs
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});

<<<<<<< HEAD
// Para requisições que contenham '/api/', sempre utiliza a rede sem fallback para cache.
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('/api/')) {
    event.respondWith(fetch(event.request));
=======
// Estratégia "network-first" para requisições da API
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('/api/')) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          return response;
        })
        .catch(() => {
          return caches.match(event.request);
        })
    );
>>>>>>> 51b834b (update tela de login customizada)
  } else {
    event.respondWith(
      caches.match(event.request)
        .then((response) => response || fetch(event.request))
    );
  }
});

// Escuta a mensagem para pular a espera
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});
