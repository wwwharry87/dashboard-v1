✅ Sidebar + Rotas criadas em frontend/ sem alterar seus arquivos existentes.

 Criados:
  - src/app/menu.js
- src/app/Sidebar.jsx
- src/app/Layout.jsx
- src/pages/DashboardMatriculas.jsx
- src/pages/DashboardMapaBimestre.jsx
- src/pages/DashboardRendimento.jsx
- src/RouterApp.jsx
- src/index-router.js

 Para testar SEM tocar no index atual:
 - Abra frontend/src/index.js e temporariamente use:
     export { default } from './index-router';
   (ou copie o conteúdo de src/index-router.js para dentro de src/index.js)

 Rotas:
 - /dash/matriculas
 - /dash/mapa-bimestre
 - /dash/rendimento
