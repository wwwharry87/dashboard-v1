// src/RouterApp.jsx
import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Layout from "./app/Layout";
import DashboardMatriculas from "./pages/DashboardMatriculas";
import DashboardMapaBimestre from "./pages/DashboardMapaBimestre";
import DashboardRendimento from "./pages/DashboardRendimento";

// estes já existem no seu projeto:
import Login from "./components/Login";
import PrivateRoute from "./components/PrivateRoute";

export default function RouterApp() {
  return (
    <BrowserRouter>
      <Routes>
        {/* default: se tiver token, vai pro painel; senão, login */}
        <Route
          path="/"
          element={
            localStorage.getItem("token")
              ? <Navigate to="/dash/matriculas" replace />
              : <Navigate to="/login" replace />
          }
        />

        {/* tela de login (pública) */}
        <Route path="/login" element={<Login />} />

        {/* rotas protegidas */}
        <Route
          path="/dash/matriculas"
          element={
            <PrivateRoute>
              <Layout title="Matrículas">
                <DashboardMatriculas />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/dash/mapa-bimestre"
          element={
            <PrivateRoute>
              <Layout title="Mapa do Bimestre">
                <DashboardMapaBimestre />
              </Layout>
            </PrivateRoute>
          }
        />
        <Route
          path="/dash/rendimento"
          element={
            <PrivateRoute>
              <Layout title="Rendimento">
                <DashboardRendimento />
              </Layout>
            </PrivateRoute>
          }
        />

        {/* 404: manda pro login */}
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
