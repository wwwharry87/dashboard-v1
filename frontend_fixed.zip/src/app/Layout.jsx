// src/app/Layout.jsx
import React, { useState } from "react";
import Sidebar from "./Sidebar";

export default function Layout({ children, title = "Dashboard" }) {
  const [collapsed, setCollapsed] = useState(true); // começa fechado (rail)
  return (
    <div className="app-shell h-screen overflow-hidden bg-gray-50">
      <header className="h-16 bg-white border-b border-gray-200 shadow-sm flex items-center px-4">
        <div className="font-semibold text-gray-800 truncate">{title}</div>
      </header>

      <div className="h-[calc(100vh-64px)] flex overflow-hidden">
        <Sidebar collapsed={collapsed} onToggle={() => setCollapsed((v) => !v)} />

        <main className="flex-1 overflow-auto">
          {/* padding do conteúdo */}
          <div className="p-4">{children}</div>
        </main>
      </div>
    </div>
  );
}
