import { FiHome, FiBarChart2, FiLayers, FiTrendingUp } from "react-icons/fi";
export const MENU = [
  { label: "Início", path: "/", icon: FiHome },
  { label: "Matrículas", path: "/dash/matriculas", icon: FiBarChart2 },
  { label: "Mapa (Bimestre)", path: "/dash/mapa-bimestre", icon: FiLayers },
  { label: "Rendimento", path: "/dash/rendimento", icon: FiTrendingUp },
];
