// src/app/Sidebar.jsx
import React from "react";
import { NavLink } from "react-router-dom";
import { FiBarChart2, FiMap, FiBookOpen, FiChevronRight } from "react-icons/fi";

const items = [
  { to: "/dash/matriculas", label: "Matrículas", icon: <FiBarChart2 /> },
  { to: "/dash/mapa-bimestre", label: "Mapa (Bimestre)", icon: <FiMap /> },
  { to: "/dash/rendimento", label: "Rendimento", icon: <FiBookOpen /> },
];

export default function Sidebar({ collapsed, onToggle }) {
  return (
    <aside
      className={`h-full bg-white border-r border-gray-200 shadow-sm flex flex-col transition-[width] duration-200 ease-out
        ${collapsed ? "w-16" : "w-64"}`}
      id="sidebar"
    >
      {/* topo */}
      <div className="h-16 flex items-center justify-between px-3">
        <div className="font-semibold text-gray-800 truncate">
          {!collapsed ? "Painéis" : " "}
        </div>
        <button
          onClick={onToggle}
          className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50"
          title={collapsed ? "Expandir" : "Recolher"}
        >
          <FiChevronRight className={`transition-transform ${collapsed ? "" : "rotate-180"}`} />
        </button>
      </div>

      {/* menu */}
      <nav className="px-2 pb-3 space-y-1 overflow-auto">
        {items.map((it) => (
          <NavLink
            key={it.to}
            to={it.to}
            className={({ isActive }) =>
              `group flex items-center gap-3 rounded-xl px-3 py-2 transition-colors
               ${isActive ? "bg-indigo-50 text-indigo-600" : "text-gray-700 hover:bg-gray-50"}`
            }
            title={collapsed ? it.label : undefined}
          >
            <span className="text-xl shrink-0">{it.icon}</span>
            {!collapsed && <span className="truncate">{it.label}</span>}
          </NavLink>
        ))}
      </nav>

      {/* rodapé opcional */}
      <div className="mt-auto p-2 text-xs text-gray-400 text-center">
        {!collapsed && "v1"}
      </div>
    </aside>
  );
}
