// src/components/Dashboard.js
import React, { useEffect, useState } from "react";
import api from "./api";
import { Bar, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
  ArcElement,
} from "chart.js";
import ChartDataLabels from "chartjs-plugin-datalabels";
import {
  FaUserGraduate,
  FaSchool,
  FaChalkboardTeacher,
  FaSignInAlt,
  FaSignOutAlt,
  FaFilter,
  FaArrowUp,
  FaArrowDown,
  FaBalanceScale,
  FaSearch,
} from "react-icons/fa";
import { Tooltip } from "react-tooltip";
import { isMobile } from "react-device-detect";
import "../index.css"; // garante tailwind + regras globais

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  ChartTooltip,
  Legend,
  ArcElement,
  ChartDataLabels
);

const formatNumber = (num) =>
  num === null || num === undefined ? 0 : Number(num).toLocaleString("pt-BR");

const reorderYesNo = (options) => {
  if (!options) return [];
  const opts = options.map(String);
  if (opts.length === 2) {
    const lower = opts.map((o) => o.toLowerCase());
    if (lower.includes("sim") && lower.includes("não")) {
      return opts.sort((a) => (a.toLowerCase() === "sim" ? -1 : 1));
    }
  }
  return opts;
};

const colorByBorder = (borderClass) =>
  ({
    "border-blue-500": "#3B82F6",
    "border-green-500": "#10B981",
    "border-purple-500": "#8B5CF6",
    "border-yellow-500": "#FBBF24",
    "border-red-500": "#EF4444",
    "border-black": "#111827",
  }[borderClass] || "#111827");

const FilterSelect = ({ label, name, options, disabled = false, value, onChange }) => {
  const ordered = reorderYesNo(options);
  return (
    <label className="block">
      <span className="text-sm font-medium text-gray-700">{label}:</span>
      <select
        name={name}
        value={value}
        onChange={onChange}
        disabled={disabled}
        className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-2 focus:ring-indigo-500"
      >
        <option value="">Todos</option>
        {ordered?.map((opt, i) => (
          <option key={i} value={opt}>
            {opt}
          </option>
        ))}
      </select>
    </label>
  );
};

const Card = ({ label, value, icon, borderColor, comparativo, disableFormat, valueColor = "" }) => {
  const iconWithColor = React.cloneElement(icon, { style: { color: colorByBorder(borderColor) } });

  const RenderComp = () =>
    comparativo && comparativo.diff != null ? (
      <div className="flex items-center justify-center mt-1">
        {comparativo.arrow === "up" ? (
          <FaArrowUp className="mr-1" style={{ color: "green" }} />
        ) : (
          <FaArrowDown className="mr-1" style={{ color: "red" }} />
        )}
        <span style={{ color: comparativo.arrow === "up" ? "green" : "red", fontSize: "0.8rem" }}>
          {comparativo.diff}%
        </span>
      </div>
    ) : null;

  return (
    <div className={`rounded-xl p-3 text-center border-l-4 ${borderColor} bg-white/90 shadow-sm hover:shadow-md transition h-28 flex flex-col items-center justify-center`}>
      <div className="text-2xl mb-1">{iconWithColor}</div>
      <h3 className="text-sm font-semibold text-gray-600">{label}</h3>
      <span className="text-xl font-bold text-gray-800 max-[430px]:text-sm" style={{ color: valueColor }}>
        {disableFormat ? value : formatNumber(value)}
      </span>
      <RenderComp />
    </div>
  );
};

export default function Dashboard() {
  const [data, setData] = useState({
    totalMatriculas: 0,
    totalEscolas: 0,
    totalVagas: 0,
    totalEntradas: 0,
    totalSaidas: 0,
    escolas: [],
    entradasSaidasPorMes: {},
    comparativos: {},
    matriculasPorZona: {},
    matriculasPorSexo: {},
    matriculasPorTurno: {},
    escolasPorZona: {},
    ultimaAtualizacao: null,
    tendenciaMatriculas: null,
  });

  const [filters, setFilters] = useState({});
  const [selectedFilters, setSelectedFilters] = useState({
    anoLetivo: "",
    deficiencia: "",
    grupoEtapa: "",
    etapaMatricula: "",
    etapaTurma: "",
    multisserie: "",
    situacaoMatricula: "",
    tipoMatricula: "",
    tipoTransporte: "",
    transporteEscolar: "",
    idescola: "",
  });

  const [selectedSchool, setSelectedSchool] = useState(null);
  const [showSidebar, setShowSidebar] = useState(false);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [tableGraphHeight, setTableGraphHeight] = useState("h-96");
  const [searchTerm, setSearchTerm] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [clientName, setClientName] = useState("");

  // se não tem token → login
  useEffect(() => {
    if (!localStorage.getItem("token")) {
      window.location.href = "/login";
    }
  }, []);

  // nome do cliente
  useEffect(() => {
    (async () => {
      try {
        const { data } = await api.get("/client");
        setClientName(data?.cliente || "");
      } catch (e) {
        console.error(e);
      }
    })();
  }, []);

  // filtros + dados
  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const { data } = await api.get("/filtros");
        setFilters(data || {});
        const ultimo = data?.ano_letivo?.[0] || "";
        const next = { ...selectedFilters, anoLetivo: ultimo };
        setSelectedFilters(next);
        await carregarDados(next);
      } catch (e) {
        console.error("Erro /filtros:", e);
      } finally {
        setLoading(false);
      }
    })();

    const clickOut = (ev) => {
      if (!ev.target.closest("#sidebar") && !ev.target.closest("#filterButton")) setShowSidebar(false);
    };
    document.addEventListener("mousedown", clickOut);
    return () => document.removeEventListener("mousedown", clickOut);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const carregarDados = async (filtros) => {
    try {
      setLoading(true);
      const [totais, breakdowns] = await Promise.all([
        api.post("/totais", filtros),
        api.post("/breakdowns", filtros),
      ]);
      setData((prev) => ({ ...prev, ...(totais?.data || {}), ...(breakdowns?.data || {}) }));
    } catch (e) {
      console.error("Erro ao carregar dados:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    const next = { ...selectedFilters, [name]: value };

    if (name === "grupoEtapa") {
      next.etapaMatricula = "";
      next.etapaTurma = "";
    }
    if (name === "etapaMatricula" && value !== "") next.etapaTurma = "";
    if (name === "etapaTurma" && value !== "") next.etapaMatricula = "";

    setSelectedFilters(next);
    carregarDados(next);
  };

  const handleSchoolClick = (escola) => {
    const next = { ...selectedFilters };
    if (selectedSchool && selectedSchool.idescola === escola.idescola) {
      setSelectedSchool(null);
      next.idescola = "";
    } else {
      setSelectedSchool(escola);
      next.idescola = escola.idescola;
    }
    setSelectedFilters(next);
    carregarDados(next);
  };

  // barra de progresso suave
  useEffect(() => {
    let t;
    if (loading) {
      setProgress(0);
      t = setInterval(() => setProgress((p) => (p < 95 ? p + 5 : p)), 250);
    } else {
      setProgress(100);
      const delay = isMobile ? 800 : 400;
      const to = setTimeout(() => setProgress(0), delay);
      return () => clearTimeout(to);
    }
    return () => clearInterval(t);
  }, [loading]);

  // altura cards/tabelas
  useEffect(() => {
    const onResize = () =>
      setTableGraphHeight(window.innerWidth <= 1180 && window.innerHeight <= 820 ? "h-64" : "h-96");
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // tendência
  let trendValue = "N/A";
  let trendValueColor = "";
  if (data.tendenciaMatriculas) {
    const { missing, percent } = data.tendenciaMatriculas;
    if (missing === 0) trendValue = "0 (0%)";
    else {
      const sign = missing > 0 ? "-" : "+";
      trendValue = `${formatNumber(Math.abs(missing))} (${sign}${percent}%)`;
      trendValueColor = missing > 0 ? "red" : "green";
    }
  }

  return (
    <div className="min-h-0 h-full w-full flex flex-col bg-gradient-to-br from-indigo-50 via-fuchsia-50 to-sky-50">
      {/* Topbar */}
      <div className="px-4 py-3 bg-white/90 backdrop-blur border-b border-gray-100 flex items-center justify-between">
        <button
          id="filterButton"
          onClick={() => setShowSidebar(true)}
          className="px-3 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition shadow"
          title="Filtros"
        >
          <FaFilter size={18} />
        </button>

        <div className="flex-1 text-center">
          <h1 className="text-xl font-bold text-gray-800">{clientName || "SEMED - TESTE"}</h1>
          <p className="text-sm text-gray-600 -mt-0.5">Painel de Matrículas</p>
        </div>

        <button
          onClick={() => {
            localStorage.removeItem("token");
            window.location.replace("/login");
          }}
          className="px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition shadow"
          title="Sair"
        >
          <FaSignOutAlt size={18} />
        </button>
      </div>

      {/* Progresso */}
      {loading && (
        <div className="fixed top-0 left-0 right-0 h-1 bg-gray-200">
          <div className="h-full bg-indigo-600 transition-all" style={{ width: `${progress}%` }} />
        </div>
      )}

      {/* Cards resumidos */}
      <div className="grid grid-cols-2 min-[480px]:grid-cols-3 md:grid-cols-6 gap-3 mb-4 px-4 pt-4">
        <div data-tooltip-id="matriculas-tooltip" data-tooltip-content={`Urbana: ${data.matriculasPorZona?.["URBANA"] || 0}\nRural: ${data.matriculasPorZona?.["RURAL"] || 0}`}>
          <Card label="Matrículas" value={data.totalMatriculas} icon={<FaUserGraduate />} borderColor="border-blue-500" comparativo={data.comparativos?.totalMatriculas} />
          <Tooltip id="matriculas-tooltip" />
        </div>
        <Card label="Comparativo" value={trendValue} icon={<FaBalanceScale />} borderColor="border-black" comparativo={null} disableFormat valueColor={trendValueColor} />
        <div data-tooltip-id="escolas-tooltip" data-tooltip-content={`Urbana: ${data.escolasPorZona?.["URBANA"] || 0}\nRural: ${data.escolasPorZona?.["RURAL"] || 0}`}>
          <Card label="Escolas" value={data.totalEscolas} icon={<FaSchool />} borderColor="border-green-500" comparativo={data.comparativos?.totalEscolas} />
          <Tooltip id="escolas-tooltip" />
        </div>
        <Card label="Vagas" value={data.totalVagas} icon={<FaChalkboardTeacher />} borderColor="border-purple-500" comparativo={data.comparativos?.totalVagas} />
        <Card label="Entradas" value={data.totalEntradas} icon={<FaSignInAlt />} borderColor="border-yellow-500" comparativo={data.comparativos?.totalEntradas} />
        <Card label="Saídas" value={data.totalSaidas} icon={<FaSignOutAlt />} borderColor="border-red-500" comparativo={data.comparativos?.totalSaidas} />
      </div>

      {/* Tabela + gráfico */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 px-4 pb-4">
        <div className={`bg-white rounded-xl shadow p-0 overflow-y-auto ${tableGraphHeight}`}>
          <div className="p-4 bg-gray-50 border-b flex justify-between items-center rounded-t-xl">
            <h3 className="text-lg font-semibold text-gray-700">Detalhes por Escola</h3>
            <button onClick={() => setShowSearch((s) => !s)}>
              <FaSearch size={18} className="text-gray-700 cursor-pointer" />
            </button>
          </div>
          {showSearch && (
            <div className="p-2">
              <input
                type="text"
                placeholder="Buscar escola..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value.toUpperCase())}
                style={{ textTransform: "uppercase" }}
                className="w-full p-2 border border-gray-300 rounded"
              />
            </div>
          )}
          <div className="overflow-x-hidden">
            <table className="min-w-full table-fixed">
              <thead className="bg-gray-50 sticky top-0 z-10">
                <tr>
                  <th className="w-1/2 px-2 py-2 text-left text-sm font-medium text-gray-700">Escola</th>
                  <th className="w-1/6 px-2 py-2 text-left text-sm font-medium text-gray-700">Turmas</th>
                  <th className="w-1/6 px-2 py-2 text-left text-sm font-medium text-gray-700">Matrículas</th>
                  <th className="w-1/6 px-2 py-2 text-left text-sm font-medium text-gray-700">Vagas</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {(data.escolas || [])
                  .filter((e) => (e.escola || "").toLowerCase().includes((searchTerm || "").toLowerCase()))
                  .map((escola, idx) => (
                    <tr
                      key={idx}
                      onClick={() => handleSchoolClick(escola)}
                      className={`cursor-pointer hover:bg-gray-50 ${
                        selectedSchool && selectedSchool.idescola === escola.idescola
                          ? "bg-indigo-50"
                          : idx % 2 === 0
                          ? "bg-white"
                          : "bg-gray-50"
                      }`}
                    >
                      <td className="px-2 py-2 text-sm text-gray-700 break-words">{escola.escola}</td>
                      <td className="px-2 py-2 text-sm text-gray-700">{escola.qtde_turmas}</td>
                      <td className="px-2 py-2 text-sm text-gray-700">{escola.qtde_matriculas}</td>
                      <td className={`px-2 py-2 text-sm font-semibold ${escola.status_vagas === "disponivel" ? "text-green-600" : "text-red-600"}`}>
                        {escola.vagas_disponiveis}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className={`bg-white rounded-xl shadow p-4 flex flex-col ${tableGraphHeight}`}>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Movimentação Mensal</h3>
          <div className="flex-1 overflow-hidden">
            <Bar
              data={{
                labels: Object.keys(data.entradasSaidasPorMes || {}),
                datasets: [
                  {
                    label: "Entradas",
                    data: Object.values(data.entradasSaidasPorMes || {}).map((e) => e.entradas),
                    backgroundColor: "#FBBF24",
                    borderRadius: 6,
                  },
                  {
                    label: "Saídas",
                    data: Object.values(data.entradasSaidasPorMes || {}).map((e) => e.saidas),
                    backgroundColor: "#EF4444",
                    borderRadius: 6,
                  },
                ],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: "top", labels: { color: "#6B7280" } },
                  datalabels: { display: false },
                },
                scales: {
                  x: { grid: { display: false }, ticks: { color: "#6B7280", font: { weight: "bold" } } },
                  y: { grid: { color: "#E5E7EB" }, ticks: { color: "#6B7280", font: { weight: "bold" }, callback: (v) => formatNumber(v) } },
                },
                layout: { padding: { top: 20, bottom: 20 } },
              }}
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 px-4 pb-4">
        <div className="bg-white rounded-xl shadow p-4 flex flex-col h-[250px]">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Matrículas por Sexo</h3>
          <div className="flex-1">
            <Pie
              data={{
                labels: Object.keys(data.matriculasPorSexo || {}),
                datasets: [
                  {
                    label: "Sexo",
                    data: Object.values(data.matriculasPorSexo || {}),
                    backgroundColor: Object.keys(data.matriculasPorSexo || {}).map((sexo) => {
                      const s = (sexo || "").toLowerCase();
                      if (s.includes("masc")) return "#3B82F6";
                      if (s.includes("femi")) return "#F472B6";
                      return "#CBD5E1";
                    }),
                    borderWidth: 0,
                  },
                ],
              }}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: "bottom" },
                  datalabels: { display: true, color: "#fff", font: { weight: "bold" }, formatter: (v) => formatNumber(v) },
                },
              }}
            />
          </div>
        </div>

        <div className="bg-white rounded-xl shadow p-4 flex flex-col h-[250px]">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Matrículas por Turno</h3>
          <div className="flex-1">
            <Bar
              data={{
                labels: Object.keys(data.matriculasPorTurno || {}),
                datasets: [
                  {
                    label: "Turno",
                    data: Object.values(data.matriculasPorTurno || {}),
                    backgroundColor: ["#4F46E5", "#10B981", "#F59E0B", "#EF4444", "#3B82F6", "#8B5CF6", "#EC4899"],
                    borderRadius: 4,
                  },
                ],
              }}
              options={{
                indexAxis: "y",
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { display: false },
                  datalabels: { display: true, color: "#fff", font: { weight: "bold" }, anchor: "end", align: "right", offset: 4, formatter: (v) => formatNumber(v) },
                },
                scales: {
                  x: { grid: { color: "#E5E7EB" }, ticks: { color: "#6B7280", font: { weight: "bold" }, callback: (v) => formatNumber(v) } },
                  y: { grid: { display: false }, ticks: { color: "#6B7280", font: { weight: "bold" } } },
                },
                layout: { padding: { left: 20, right: 20 } },
              }}
            />
          </div>
        </div>
      </div>

      {/* Sidebar de filtros (slide-over) */}
      <div
        id="sidebar"
        className={`fixed inset-y-0 left-0 bg-white w-64 md:w-80 p-6 shadow-2xl transform ${
          showSidebar ? "translate-x-0" : "-translate-x-full"
        } transition-transform duration-300 ease-in-out z-50`}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-800">Filtros</h2>
          <button onClick={() => setShowSidebar(false)} className="text-gray-500 hover:text-gray-700 transition">
            ✕
          </button>
        </div>

        <div className="space-y-3">
          <FilterSelect label="Ano Letivo" name="anoLetivo" options={filters.ano_letivo} value={selectedFilters.anoLetivo} onChange={handleFilterChange} />
          <FilterSelect label="Tipo Matrícula" name="tipoMatricula" options={filters.tipo_matricula} value={selectedFilters.tipoMatricula} onChange={handleFilterChange} />
          <FilterSelect label="Situação Matrícula" name="situacaoMatricula" options={filters.situacao_matricula} value={selectedFilters.situacaoMatricula} onChange={handleFilterChange} />
          <FilterSelect label="Grupo Etapa" name="grupoEtapa" options={filters.grupo_etapa} value={selectedFilters.grupoEtapa} onChange={handleFilterChange} />
          <FilterSelect
            label="Etapa Matrícula"
            name="etapaMatricula"
            options={selectedFilters.grupoEtapa && filters.etapasMatriculaPorGrupo ? filters.etapasMatriculaPorGrupo[selectedFilters.grupoEtapa] : filters.etapa_matricula}
            value={selectedFilters.etapaMatricula}
            onChange={handleFilterChange}
            disabled={selectedFilters.etapaTurma !== ""}
          />
          <FilterSelect
            label="Etapa Turma"
            name="etapaTurma"
            options={selectedFilters.grupoEtapa && filters.etapasTurmaPorGrupo ? filters.etapasTurmaPorGrupo[selectedFilters.grupoEtapa] : filters.etapa_turma}
            value={selectedFilters.etapaTurma}
            onChange={handleFilterChange}
            disabled={selectedFilters.etapaMatricula !== ""}
          />
          <FilterSelect label="Multissérie" name="multisserie" options={filters.multisserie} value={selectedFilters.multisserie} onChange={handleFilterChange} />
          <FilterSelect label="Deficiência" name="deficiencia" options={filters.deficiencia} value={selectedFilters.deficiencia} onChange={handleFilterChange} />
          <FilterSelect label="Transporte Escolar" name="transporteEscolar" options={filters.transporte_escolar} value={selectedFilters.transporteEscolar} onChange={handleFilterChange} />
          <FilterSelect label="Tipo Transporte" name="tipoTransporte" options={filters.tipo_transporte} value={selectedFilters.tipoTransporte} onChange={handleFilterChange} />
        </div>
      </div>
    </div>
  );
}
