import React from "react";
import Layout from "../app/Layout";
export default function DashboardMapaBimestre() {
  return (
    <Layout title="Mapa Estatístico — Bimestre">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="rounded-lg border p-4 bg-white">Card 1</div>
        <div className="rounded-lg border p-4 bg-white">Card 2</div>
        <div className="rounded-lg border p-4 bg-white">Card 3</div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
        <div className="rounded-lg border p-4 bg-white h-64">Gráfico A</div>
        <div className="rounded-lg border p-4 bg-white h-64">Gráfico B</div>
        <div className="rounded-lg border p-4 bg-white h-64">Gráfico C</div>
      </div>
    </Layout>
  );
}
