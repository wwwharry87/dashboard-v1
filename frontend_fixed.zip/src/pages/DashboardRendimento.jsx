import React from "react";
import Layout from "../app/Layout";
export default function DashboardRendimento() {
  return (
    <Layout title="Rendimento">
      <div className="rounded-lg border p-4 bg-white">Placeholder de Rendimento</div>
    </Layout>
  );
}
