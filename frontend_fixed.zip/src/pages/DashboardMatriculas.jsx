import React from "react";
import Layout from "../app/Layout";
import Dashboard from "../components/Dashboard";
export default function DashboardMatriculas() {
  return (
    <Layout title="Matrículas">
      <Dashboard />
    </Layout>
  );
}
